var md5 = require("blueimp-md5");
var hash = md5("12345");
console.log(hash);
